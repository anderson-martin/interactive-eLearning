        $(document).ready(function () {

            $(".draggable").draggable({
                revert: "invalid"
            });
            $("#component0").droppable({
                accept: '#answer0'
                , activeClass: "ui-state-hover"
                , hoverClass: "ui-state-active"
                , drop: function (event, ui) {
                    $(this).addClass("ui-state-highlight");
                    myVars.index = 0;
                    component().starter();
                }
            });
            $("#component1").droppable({
                accept: '#answer1'
                , activeClass: "ui-state-hover"
                , hoverClass: "ui-state-active"
                , drop: function (event, ui) {
                    $(this).addClass("ui-state-highlight");
                    myVars.index = 1;
                    component().starter();
                }
            });
            $("#component2").droppable({
                accept: '#answer2'
                , activeClass: "ui-state-hover"
                , hoverClass: "ui-state-active"
                , drop: function (event, ui) {
                    $(this).addClass("ui-state-highlight");
                    myVars.index = 2;
                    component().starter();
                }
            });
            $("#component3").droppable({
                accept: '#answer3'
                , activeClass: "ui-state-hover"
                , hoverClass: "ui-state-active"
                , drop: function (event, ui) {
                    $(this).addClass("ui-state-highlight");
                    myVars.index = 3;
                    component().starter();
                }
            });
            //?? why the current structure works fine? It shouldn't! Following functions are defined within scope of the anon function (initialized after document ready). And these functions don#t have global scope (havent attached them with window object). so how comes that i can call them easily and eveything works fine?
            $(myVars = {
                i: 0
                , index: NaN
            });
            $(component = function () {
                var BtnIsOff = true;
                var dialogs = getDialogs();
                var choices = ['Accounts recievable', 'Accounts payable ', 'Advances received ', 'Inventory '];
                /* due to hoisting, variables are being declared at the beginning but they dont instantiate. so, how comes that we can use function expression like following:
                
                func();
                function(){};
                
                it shouldnt be possible! */
                fillPage();

                function fillPage() {
                    $(".answer0").text(choices[0]);
                    $(".answer1").text(choices[1]);
                    $(".answer2").text(choices[2]);
                    $(".answer3").text(choices[3]);
                };
                var starter = function () {
                    component().runModal();
                    myVars.i = 0;
                    component().showQuestion();
                };
                var runModal = function () {
                    // Get the modal
                    var modal = document.getElementById('myModal');
                    // Get the button that opens the modal
                    var btn = document.getElementById("myBtn");
                    // Get the <span> element that closes the modal
                    var span = document.getElementsByClassName("close")[0];
                    // When the user clicks the button, open the modal 
                    modal.style.display = "block";
                };
                var showTrue = function () {
                    /*
                    document.getElementById("answerArea").style.display = "block";
                    */
                    document.getElementById("trueAnswer").style.display = "block";
                    document.getElementById("nextBtn").style.display = "block";
                    document.getElementById("trueAnswer").innerHTML = dialogs[myVars.index].trueAnswers[myVars.i];
                    document.getElementById("falseBtn").style.display = "none";
                    document.getElementById("trueBtn").style.display = "none";
                    document.getElementById("textInBetween").style.display = "none";
                };
                var showFalse = function () {
                    /*
                    document.getElementById("answerArea").style.display = "block";
                    */
                    document.getElementById("wrongAnswer").style.display = "block";
                    document.getElementById("nextBtn").style.display = "block";
                    document.getElementById("wrongAnswer").innerHTML = dialogs[myVars.index].wrongAnswers[myVars.i];
                    document.getElementById("falseBtn").style.display = "none";
                    document.getElementById("trueBtn").style.display = "none";
                    document.getElementById("textInBetween").style.display = "none";
                };
                var turnOnBtns = function () {
                    document.getElementById("falseBtn").style.display = "block";
                    document.getElementById("trueBtn").style.display = "block";
                    document.getElementById("textInBetween").style.display = "block";
                };
                var showQuestion = function () {
                    document.getElementById("question").innerHTML = dialogs[myVars.index].questions[myVars.i];
                };
                var nextPage = function () {
                    myVars.i++;
                    showQuestion();
                    turnOnBtns();
                    /*
                    document.getElementById("answerArea").style.display = "none"; */
                    document.getElementById("trueAnswer").innerHTML = "";
                    document.getElementById("wrongAnswer").innerHTML = "";
                    console.log('"retunedAnswer" + myVars.index is ' + "retunedAnswer" + myVars.index);
                    if (myVars.i === 3) {
                        document.getElementById('myModal').style.display = "none";
                        document.getElementById("answer" + myVars.index).style.display = "none";
                        document.getElementById("placeholder" + myVars.index).style.display = "none";
                        document.getElementById("retunedAnswer" + myVars.index).style.display = "";
                    }
                };
                return {
                    showTrue: showTrue
                    , showFalse: showFalse
                    , showQuestion: showQuestion
                    , nextPage: nextPage
                    , runModal: runModal
                    , starter: starter
                };
            });
        });