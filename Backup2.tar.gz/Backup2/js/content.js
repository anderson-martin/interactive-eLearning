        $(document).ready(function () {
            $(getDialogs = function () {
                console.log('getDialogs has been called');
                var dialogs = [
                    {
                        questions: [' 1 question 1', '1 question 2', '1 question 3']
                        , trueAnswers: ['1 correct answer 1 ', '1 correct answer 2', '1 correct answer 3']
                        , wrongAnswers: ['1 wrong answer 1', '1 wrong answer 2', '1 wrong answer 3']
                }
                , {
                        questions: [' 2 question 1', '2 question 2', '2 question 3']
                        , trueAnswers: ['2 correct answer 1 ', '2 correct answer 2', '2 correct answer 3']
                        , wrongAnswers: ['2 wrong answer 1', '2 wrong answer 2', '2 wrong answer 3']
                }
                , {
                        questions: [' 3 question 1', '3 question 2', '3 question 3']
                        , trueAnswers: ['3 correct answer 1 ', '3 correct answer 2', '3 correct answer 3']
                        , wrongAnswers: ['3 wrong answer 1', '3 wrong answer 2', '3 wrong answer 3']
                }
                , {
                        questions: [' 4 question 1', '4 question 2', '4 question 3']
                        , trueAnswers: ['4 correct answer 1 ', '4 correct answer 2', '4 correct answer 3']
                        , wrongAnswers: ['4 wrong answer 1', '4 wrong answer 2', '4 wrong answer 3']
                }
            ];
                
                return dialogs;
            });
        });