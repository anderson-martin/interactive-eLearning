       /* Functions for the section four of page 2 were repetative and bulky. So, I outsourced theme here. */
       $(document).ready(function () {
           $(getFuncs = function () {
               var funcs4SectionFourth = ['            <div id="component0" class="col-md-3 col-sm-12 col-xs-12 component droppable left">                <hr class="vertical">                <!-- "bg" stands for "background" -->                <div class="bg-placeholder">                    <div id="placeholder0" class="placeholder"> </div>                    <div id="retunedAnswer0" class="retunedAnswer row" style="display:none;">                        <div class="col-md-4 col-sm-4 col-xs-4"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x white" aria-hidden="true"></i>  <i class="fa fa-plus-circle fa-stack-2x black"></i></span></div>                        <div class="col-md-6 col-sm-6 col-xs-6 left answer0"> </div>                    </div>                </div>                <div class="bg-description">                    <div class="description desc0"> </div>                </div>            </div>'];
               return {
                   funcs4SectionFourth: funcs4SectionFourth
               }
           });
       });