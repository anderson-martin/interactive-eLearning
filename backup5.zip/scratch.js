  var fourth = document.getElementById("fourth");
var component0  =  $("<div></div>", {
    "class":  "col-md-3 col-sm-12 col-xs-12 component droppable left",
    id:  "component0"
}).append(fourth);


