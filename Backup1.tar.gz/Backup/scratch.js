var myArray = {
    component : ["one", "two"]
};


console.log(myArray.component[0]);