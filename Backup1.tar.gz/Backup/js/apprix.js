        $(document).ready(function () {
            $(".draggable").draggable({
                revert: "invalid"
            });
            $("#component1").droppable({
                accept: '#answer1'
                , activeClass: "ui-state-hover"
                , hoverClass: "ui-state-active"
                , drop: function (event, ui) {
                    $(this).addClass("ui-state-highlight");
                    myVars.index = 0;
                    component().starter();
                }
            });
            $("#component2").droppable({
                accept: '#answer2'
                , activeClass: "ui-state-hover"
                , hoverClass: "ui-state-active"
                , drop: function (event, ui) {
                    $(this).addClass("ui-state-highlight");
                    myVars.index = 1;
                    component().starter();
                }
            });
            $("#component3").droppable({
                accept: '#answer3'
                , activeClass: "ui-state-hover"
                , hoverClass: "ui-state-active"
                , drop: function (event, ui) {
                    $(this).addClass("ui-state-highlight");
                    myVars.index = 2;
                    component().starter();
                }
            });
            $("#component4").droppable({
                accept: '#answer4'
                , activeClass: "ui-state-hover"
                , hoverClass: "ui-state-active"
                , drop: function (event, ui) {
                    $(this).addClass("ui-state-highlight");
                    myVars.index = 3;
                    component().starter();
                }
            });
            //?? why the current structure works fine? It shouldn't! Following functions are defined within scope of the anon function (initialized after document ready). And these functions don#t have global scope (havent attached them with window object). so how comes that i can call them easily and eveything works fine?
            $(myVars = {
                i: 0
                , index: NaN
            });
            $(component = function () {
                var BtnIsOff = true;
                var content = [
                    {
                        questions: [' 1 question 1', '1 question 2', '1 question 3']
                        , trueAnswers: ['1 correct answer 1 ', '1 correct answer 2', '1 correct answer 3']
                        , wrongAnswers: ['1 wrong answer 1', '1 wrong answer 2', '1 wrong answer 3']
                }
                , {
                        questions: [' 2 question 1', '2 question 2', '2 question 3']
                        , trueAnswers: ['2 correct answer 1 ', '2 correct answer 2', '2 correct answer 3']
                        , wrongAnswers: ['2 wrong answer 1', '2 wrong answer 2', '2 wrong answer 3']
                }
                , {
                        questions: [' 3 question 1', '3 question 2', '3 question 3']
                        , trueAnswers: ['3 correct answer 1 ', '3 correct answer 2', '3 correct answer 3']
                        , wrongAnswers: ['3 wrong answer 1', '3 wrong answer 2', '3 wrong answer 3']
                }
                , {
                        questions: [' 4 question 1', '4 question 2', '4 question 3']
                        , trueAnswers: ['4 correct answer 1 ', '4 correct answer 2', '4 correct answer 3']
                        , wrongAnswers: ['4 wrong answer 1', '4 wrong answer 2', '4 wrong answer 3']
                }
            ];
                var starter = function () {
                    component().runModal();
                    myVars.i = 0;
                    component().showQuestion();
                };
                var runModal = function () {
                    // Get the modal
                    var modal = document.getElementById('myModal');
                    // Get the button that opens the modal
                    var btn = document.getElementById("myBtn");
                    // Get the <span> element that closes the modal
                    var span = document.getElementsByClassName("close")[0];
                    // When the user clicks the button, open the modal 
                    modal.style.display = "block";

                };
                var showTrue = function () {
                    /*
                    document.getElementById("answerArea").style.display = "block";
                    */
                    document.getElementById("trueAnswer").style.display = "block";
                    document.getElementById("nextBtn").style.display = "block";
                    document.getElementById("trueAnswer").innerHTML = content[myVars.index].trueAnswers[myVars.i];
                    document.getElementById("falseBtn").disabled = true;
                };
                var showFalse = function () {
                    /*
                    document.getElementById("answerArea").style.display = "block";
                    */
                    document.getElementById("wrongAnswer").style.display = "block";
                    document.getElementById("nextBtn").style.display = "block";
                    document.getElementById("wrongAnswer").innerHTML = content[myVars.index].wrongAnswers[myVars.i];
                    document.getElementById("trueBtn").disabled = true;
                };
                var turnOnBtns = function () {
                    document.getElementById("falseBtn").disabled = false;
                    document.getElementById("trueBtn").disabled = false;
                };
                var showQuestion = function () {
                    document.getElementById("question").innerHTML = content[myVars.index].questions[myVars.i];
                };
                var nextPage = function () {
                    myVars.i++;
                    showQuestion();
                    turnOnBtns();
                    /*
                    document.getElementById("answerArea").style.display = "none"; */
                    document.getElementById("trueAnswer").innerHTML = "";
                    document.getElementById("wrongAnswer").innerHTML = "";
                    if (myVars.i === 3) {
                        document.getElementById('myModal').style.display = "none";
                    }
                };
                return {
                    showTrue: showTrue
                    , showFalse: showFalse
                    , showQuestion: showQuestion
                    , nextPage: nextPage
                    , runModal: runModal
                    , starter: starter
                };
            });
        });
        /*
                var myVars = {
                    i: 0
                    , index: NaN
                };

                var component = function () {
                    var BtnIsOff = true;
                    var content = [
                        {
                            questions: [' 1 question 1', '1 question 2', '1 question 3']
                            , trueAnswers: ['1 correct answer 1 ', '1 correct answer 2', '1 correct answer 3']
                            , wrongAnswers: ['1 wrong answer 1', '1 wrong answer 2', '1 wrong answer 3']
                        }
                        , {
                            questions: [' 2 question 1', '2 question 2', '2 question 3']
                            , trueAnswers: ['2 correct answer 1 ', '2 correct answer 2', '2 correct answer 3']
                            , wrongAnswers: ['2 wrong answer 1', '2 wrong answer 2', '2 wrong answer 3']
                        }
                        , {
                            questions: [' 3 question 1', '3 question 2', '3 question 3']
                            , trueAnswers: ['3 correct answer 1 ', '3 correct answer 2', '3 correct answer 3']
                            , wrongAnswers: ['3 wrong answer 1', '3 wrong answer 2', '3 wrong answer 3']
                        }
                        , {
                            questions: [' 4 question 1', '4 question 2', '4 question 3']
                            , trueAnswers: ['4 correct answer 1 ', '4 correct answer 2', '4 correct answer 3']
                            , wrongAnswers: ['4 wrong answer 1', '4 wrong answer 2', '4 wrong answer 3']
                        }
                    ];
                    var runModal = function () {
                        // Get the modal
                        var modal = document.getElementById('myModal');
                        // Get the button that opens the modal
                        var btn = document.getElementById("myBtn");
                        // Get the <span> element that closes the modal
                        var span = document.getElementsByClassName("close")[0];
                        // When the user clicks the button, open the modal 
                        modal.style.display = "block";
                        // When the user clicks on <span> (x), close the modal
                        span.onclick = function () {
                            modal.style.display = "none";
                                                    myVars.i = 0;
                        }
                    };
                    var showTrue = function () {
                        document.getElementById("answerArea").style.display = "block";
                        document.getElementById("trueAnswer").style.display = "block";
                        document.getElementById("nextBtn").style.display = "block";
                        document.getElementById("trueAnswer").innerHTML = content[myVars.index].trueAnswers[myVars.i];
                        document.getElementById("falseBtn").disabled = true;
                    };
                    var showFalse = function () {
                        document.getElementById("answerArea").style.display = "block";
                        document.getElementById("wrongAnswer").style.display = "block";
                        document.getElementById("nextBtn").style.display = "block";
                        document.getElementById("wrongAnswer").innerHTML = content[myVars.index].wrongAnswers[myVars.i];
                        document.getElementById("trueBtn").disabled = true;
                    };
                    var turnOnBtns = function () {
                        document.getElementById("falseBtn").disabled = false;
                        document.getElementById("trueBtn").disabled = false;
                    };
                    var showQuestion = function () {
                        console.log('myVars.i is ' + myVars.i);
                        console.log('myVars.index is ' + myVars.index);
                        document.getElementById("question").innerHTML = content[myVars.index].questions[myVars.i];
                    };
                    var nextPage = function () {
                        myVars.i++;
                        showQuestion();
                        turnOnBtns();
                        document.getElementById("answerArea").style.display = "none";
                        document.getElementById("trueAnswer").innerHTML = "";
                        document.getElementById("wrongAnswer").innerHTML = "";
                        if (myVars.i === 3) {
                            document.getElementById('myModal').style.display = "none";
                        }
                    };
                    return {
                        showTrue: showTrue
                        , showFalse: showFalse
                        , showQuestion: showQuestion
                        , nextPage: nextPage
                        , runModal: runModal
                    };
                };
                
                */